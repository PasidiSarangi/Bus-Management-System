import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { 
  User, 
  Mail, 
  Phone, 
  MapPin, 
  Calendar, 
  Clock, 
  Ticket, 
  Trash2,
  AlertCircle
} from 'lucide-react';
import toast from 'react-hot-toast';
import { useNavigate } from 'react-router-dom';

function ProfilePage() {
  const [profileData, setProfileData] = useState({
    firstName: '',
    lastName: '',
    email: '',
    contactNumber: '',
    profilePhoto: null
  });
  const [bookings, setBookings] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [deletingId, setDeletingId] = useState(null);
  const [showCancelModal, setShowCancelModal] = useState(false);
  const [bookingToCancel, setBookingToCancel] = useState(null);
  const [isCancelling, setIsCancelling] = useState(false);
  const navigate = useNavigate();

  // Fetch user data and bookings
  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        setError(null);
        
        // Fetch user data
        const userResponse = await axios.get(
          `${import.meta.env.VITE_BACKEND_URL}/api/users/user/`, 
          {
            headers: {
              Authorization: `Bearer ${localStorage.getItem('token')}`
            }
          }
        );
        
        const { firstName, lastName, email, contactNumber, profilepic } = userResponse.data;
        setProfileData({
          firstName: firstName || '',
          lastName: lastName || '',
          email: email || '',
          contactNumber: contactNumber || '',
          profilePhoto: profilepic || null
        });

        // Fetch bookings
        const bookingsResponse = await axios.get(
          `${import.meta.env.VITE_BACKEND_URL}/api/bookings/getbookings`,
          {
            headers: {
              Authorization: `Bearer ${localStorage.getItem('token')}`
            }
          }
        );
        
        setBookings(bookingsResponse.data);
      } catch (err) {
        console.error('Error fetching data:', err);
        setError(err.response?.data?.message || 'Failed to load data');
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  // Calculate if booking can be cancelled (>2 hours remaining)
  const canCancelBooking = (departureDateTime) => {
    const now = new Date();
    const diffHours = (departureDateTime - now) / (1000 * 60 * 60);
    return diffHours > 2;
  };

  // Format departure date and time
  const formatDeparture = (booking) => {
    return new Date(`${booking.bookingDate}T${booking.time}`);
  };

  const handleDelete = async (bookingId) => {
    try {
      setDeletingId(bookingId);
      const booking = bookings.find(b => b._id === bookingId);
      if (!booking) {
        throw new Error('Booking not found');
      }
      const departure = formatDeparture(booking);
      if (!canCancelBooking(departure)) {
        throw new Error('Cannot cancel within 2 hours of departure');
      }
  
      await axios.delete(
        `${import.meta.env.VITE_BACKEND_URL}/api/bookings/${bookingId}`,
        {
          headers: {
            Authorization: `Bearer ${localStorage.getItem('token')}`
          }
        }
      );
      
      setBookings(bookings.filter(booking => booking._id !== bookingId));
      toast.success("Booking Cancel Successfully")
    } catch (err) {
      console.error('Error deleting booking:', err);
      setError(err.response?.data?.message || err.message);
    } finally {
      setDeletingId(null);
    }
  };

  // Format time remaining
  const formatTimeRemaining = (departure) => {
    const now = new Date();
    const diffMs = departure - now;
    const diffHours = Math.max(0, Math.ceil(diffMs / (1000 * 60 * 60)));
    
    if (diffHours <= 0) {
      return <span className="text-red-500">Departed</span>;
    }
    if (diffHours <= 2) {
      return <span className="text-red-500">{diffHours}h remaining (Non-refundable)</span>;
    }
    return <span className="text-green-500">Cancellable ({diffHours}h remaining)</span>;
  };

  const handleCancelBooking = async () => {
    if (!bookingToCancel) return;

    setIsCancelling(true);
    try {
      const token = localStorage.getItem('token');
      const userId = localStorage.getItem('userId');

      if (!token || !userId) {
        throw new Error('User not authenticated');
      }

      await axios.delete(
        `${import.meta.env.VITE_BACKEND_URL}/api/bookings/${bookingToCancel._id}`,
        {
          data: { userId },
          headers: {
            'Authorization': `Bearer ${token}`
          }
        }
      );

      toast.success('Booking cancelled successfully');
      // Refresh the bookings list
      // You might want to add a function to refresh the bookings here
    } catch (error) {
      toast.error(error.response?.data?.error || 'Failed to cancel booking');
    } finally {
      setIsCancelling(false);
      setShowCancelModal(false);
      setBookingToCancel(null);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-900 flex items-center justify-center">
        <div className="text-white text-xl">Loading your bookings...</div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-gray-900 flex items-center justify-center">
        <div className="text-red-500 max-w-md text-center">
          <AlertCircle className="mx-auto mb-4" size={48} />
          <h2 className="text-xl font-bold mb-2">Error Loading Data</h2>
          <p>{error}</p>
          <button 
            onClick={() => window.location.reload()}
            className="mt-4 px-4 py-2 bg-blue-600 rounded hover:bg-blue-700"
          >
            Try Again
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-900 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-6xl mx-auto space-y-8">
        {/* Profile Section */}
        <div className="bg-gray-800 rounded-lg shadow-lg overflow-hidden">
          <div className="px-6 py-8 text-center relative">
            <div className="absolute inset-0 bg-gradient-to-br from-blue-900/20 to-purple-900/20 opacity-30"></div>
            <div className="relative">
              <div className="relative inline-block">
                <div className="w-32 h-32 rounded-full overflow-hidden border-4 border-white/20 bg-gray-700 mx-auto">
                  {profileData.profilePhoto ? (
                    <img 
                      src={profileData.profilePhoto} 
                      alt="Profile" 
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center">
                      <User className="w-16 h-16 text-gray-400" />
                    </div>
                  )}
                </div>
              </div>
              <div className="mt-4">
                <h2 className="text-2xl font-bold text-white">
                  {profileData.firstName} {profileData.lastName}
                </h2>
                <p className="text-gray-300">{profileData.email}</p>
              </div>
            </div>
          </div>
        </div>

        {/* Bookings Section */}
        <div className="bg-gray-800 rounded-lg shadow-lg overflow-hidden">
          <div className="px-6 py-8">
            <h2 className="text-2xl font-bold text-white mb-6">Your Bookings</h2>
            
            {bookings.length === 0 ? (
              <div className="text-center py-12">
                <p className="text-gray-400">You haven't made any bookings yet</p>
              </div>
            ) : (
              <div className="space-y-4">
                {bookings.map((booking) => {
                  const departure = formatDeparture(booking);
                  return (
                    <div key={booking._id} className="bg-gray-700/50 rounded-lg p-6 border border-gray-600 hover:border-gray-500 transition-colors">
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-4">
                        {/* Route */}
                        <div className="flex items-start space-x-3">
                          <MapPin className="flex-shrink-0 text-blue-400 mt-1" />
                          <div>
                            <h3 className="font-medium text-white">Route</h3>
                            <p className="text-gray-300">
                              {booking.startLocation} → {booking.endLocation}
                            </p>
                          </div>
                        </div>

                        {/* Date/Time */}
                        <div className="flex items-start space-x-3">
                          <div className="flex-shrink-0">
                            <Calendar className="text-blue-400 inline mr-2" />
                            <Clock className="text-blue-400 inline" />
                          </div>
                          <div>
                            <h3 className="font-medium text-white">Departure</h3>
                            <p className="text-gray-300">
                              {departure.toLocaleString()}
                            </p>
                          </div>
                        </div>

                        {/* Status */}
                        <div className="flex items-start space-x-3">
                          <Ticket className="flex-shrink-0 text-blue-400 mt-1" />
                          <div>
                            <h3 className="font-medium text-white">Status</h3>
                            <p className="text-sm">
                              {formatTimeRemaining(departure)}
                            </p>
                          </div>
                        </div>
                      </div>

                      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 pt-4 border-t border-gray-600">
                        <div className="space-y-1">
                          <p className="text-white">
                            <span className="font-medium">Seats: </span>
                            <span className="text-gray-300">{booking.seats.join(', ')}</span>
                          </p>
                          <p className="text-white">
                            <span className="font-medium">Total: </span>
                            <span className="text-yellow-400">${booking.totalPrice}</span>
                          </p>
                        </div>

                        <div className="flex space-x-3">
                          {canCancelBooking(departure) ? (
                            <button
                              onClick={() => {
                                setBookingToCancel(booking);
                                setShowCancelModal(true);
                              }}
                              className="flex items-center px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors"
                            >
                              <Trash2 className="w-4 h-4 mr-2" />
                              Cancel Booking
                            </button>
                          ) : (
                            <div className="text-sm text-gray-400 flex items-center">
                              <AlertCircle className="mr-2" size={16} />
                              Cancellation unavailable
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Cancellation Confirmation Modal */}
      {showCancelModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-gray-800 rounded-lg p-6 max-w-md w-full mx-4">
            <h2 className="text-xl font-semibold text-white mb-4">Cancel Booking</h2>
            <p className="text-gray-300 mb-6">
              Are you sure you want to cancel this booking? This action cannot be undone.
            </p>
            <div className="flex justify-end gap-4">
              <button
                onClick={() => {
                  setShowCancelModal(false);
                  setBookingToCancel(null);
                }}
                className="px-4 py-2 bg-gray-600 text-white rounded-lg hover:bg-gray-700 transition-colors"
              >
                No, Keep Booking
              </button>
              <button
                onClick={handleCancelBooking}
                disabled={isCancelling}
                className="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors disabled:bg-red-400 disabled:cursor-not-allowed flex items-center"
              >
                {isCancelling ? (
                  <>
                    Cancelling...
                    <svg className="animate-spin h-4 w-4 ml-2" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                    </svg>
                  </>
                ) : (
                  'Yes, Cancel Booking'
                )}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default ProfilePage;