import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';

const Home = () => {
  const navigate = useNavigate();
  const [buses, setBuses] = useState([]);

  useEffect(() => {
    // Fetch buses from the backend
    fetchBuses();
  }, []);

  const fetchBuses = async () => {
    try {
      const response = await fetch('/api/buses');
      const data = await response.json();
      setBuses(data);
    } catch (error) {
      console.error('Error fetching buses:', error);
    }
  };

  return (
    <div className="container mx-auto p-4">
      {/* Rest of the component code */}
      <div className="flex justify-end space-x-4">
        <button
          onClick={() => navigate(`/bus-timetable/${bus._id}`)}
          className="bg-gray-600 text-white px-4 py-2 rounded-lg hover:bg-gray-700 transition-colors"
        >
          See Timetable
        </button>
        <button
          onClick={() => navigate(`/book-ticket/${bus._id}`)}
          className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors"
        >
          Book Ticket
        </button>
      </div>
    </div>
  );
};

export default Home; 