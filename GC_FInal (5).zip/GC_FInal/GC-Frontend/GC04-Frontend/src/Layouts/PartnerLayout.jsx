import React from 'react'
import Partners from '../Component/Partners'

function PartnerLayout() {
  return (
    <Partners/>
  )
}

export default PartnerLayout
