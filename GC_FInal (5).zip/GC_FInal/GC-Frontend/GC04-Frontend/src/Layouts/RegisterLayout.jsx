import React from 'react'
import Register from '../Component/Register'

function RegisterLayout() {
  return (
    <div className='w-full'>
     <Register/>
    </div>
  )
}

export default RegisterLayout
