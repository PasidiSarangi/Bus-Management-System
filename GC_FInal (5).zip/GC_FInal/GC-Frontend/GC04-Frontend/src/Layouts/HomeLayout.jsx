import React from 'react'
import Hero from '../Component/Hero'

function HomeLayout() {
  return (
    <div>
      <Hero/>
    </div>
  )
}

export default HomeLayout
