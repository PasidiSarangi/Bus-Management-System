import BusTimetable from './Pages/BusTimetable';

<Route path="/bus-timetable/:busId" element={<BusTimetable />} /> 